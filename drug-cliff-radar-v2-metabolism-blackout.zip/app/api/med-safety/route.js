import { NextResponse } from "next/server";

const FDA = "https://api.fda.gov";

const CLANCY_CASE_MEDS = [
  { generic: "zolpidem", brand: "Ambien" },
  { generic: "clonazepam", brand: "Klonopin" },
  { generic: "diazepam", brand: "Valium" },
  { generic: "fluoxetine", brand: "Prozac" },
  { generic: "lamotrigine", brand: "Lamictal" },
  { generic: "lorazepam", brand: "Ativan" },
  { generic: "mirtazapine", brand: "Remeron" },
  { generic: "quetiapine", brand: "Seroquel" },
  { generic: "sertraline", brand: "Zoloft" },
  { generic: "trazodone", brand: "Trazodone" },
  { generic: "hydroxyzine", brand: "Hydroxyzine" },
  { generic: "amitriptyline", brand: "Amitriptyline" },
  { generic: "buspirone", brand: "Buspar" }
];

function cleanDrug(input = "") {
  return input.trim().replace(/["\\]/g, "").slice(0, 80);
}

async function fetchJson(url) {
  const res = await fetch(url, {
    headers: { "User-Agent": "Drug-Cliff-Radar/2.2" },
    cache: "no-store"
  });
  if (!res.ok) {
    if (res.status === 404) return null;
    throw new Error(`openFDA request failed (${res.status})`);
  }
  return res.json();
}

function firstArrayValue(obj, key) {
  const value = obj?.[key];
  if (!Array.isArray(value) || !value.length) return null;
  return value[0];
}

function labelCorpus(label = {}) {
  return [
    firstArrayValue(label, "drug_interactions"),
    firstArrayValue(label, "warnings_and_cautions"),
    firstArrayValue(label, "warnings"),
    firstArrayValue(label, "adverse_reactions"),
    firstArrayValue(label, "clinical_pharmacology"),
    firstArrayValue(label, "pharmacokinetics"),
    firstArrayValue(label, "indications_and_usage")
  ].filter(Boolean).join(" ");
}

function excerptAround(text = "", terms = [], radius = 180) {
  const lower = text.toLowerCase();
  let idx = -1;
  for (const term of terms) {
    const hit = lower.indexOf(term.toLowerCase());
    if (hit >= 0 && (idx < 0 || hit < idx)) idx = hit;
  }
  if (idx < 0) return null;
  const start = Math.max(0, idx - radius);
  const end = Math.min(text.length, idx + radius);
  return `${start > 0 ? "…" : ""}${text.slice(start, end).replace(/\s+/g, " ").trim()}${end < text.length ? "…" : ""}`;
}

function analyzeEverydaySubstances(label = {}) {
  const interactions = labelCorpus(label).toLowerCase();
  const has = (...terms) => terms.some(t => interactions.includes(t));
  const classify = ({directTerms=[], mechanismTerms=[]}) => {
    const direct = directTerms.some(t => interactions.includes(t));
    const mechanism = mechanismTerms.some(t => interactions.includes(t));
    if (direct) return { tested: "Mentioned in FDA labeling", evidence: "Label evidence", level: "Moderate–Strong" };
    if (mechanism) return { tested: "Mechanism suggests possible interaction", evidence: "Mechanistic / label inference", level: "Limited–Moderate" };
    return { tested: "No direct study found in returned FDA label", evidence: "Evidence gap", level: "Unknown / limited" };
  };

  return {
    alcohol: {
      ...classify({ directTerms:["alcohol","ethanol"], mechanismTerms:["central nervous system depress","sedation","somnolence","hepatic","liver"] }),
      labelMention: has("alcohol","ethanol"),
      note: has("alcohol","ethanol") ? "FDA labeling returned a direct alcohol/ethanol reference." : "The returned FDA label did not contain a direct alcohol/ethanol interaction statement."
    },
    cannabis: {
      ...classify({ directTerms:["cannabis","marijuana","tetrahydrocannabinol","thc","cannabidiol","cbd"], mechanismTerms:["cyp3a4","cyp2c19","cyp2d6","cyp1a2","sedation","somnolence"] }),
      labelMention: has("cannabis","marijuana","tetrahydrocannabinol","thc","cannabidiol","cbd"),
      note: has("cannabis","marijuana","tetrahydrocannabinol","thc","cannabidiol","cbd") ? "FDA labeling returned a cannabis/THC/CBD reference." : "Direct cannabis/THC/CBD interaction data were not found in the returned FDA label; mechanism-based interaction potential may still exist."
    },
    tobaccoNicotine: {
      ...classify({ directTerms:["tobacco","smoking","nicotine","cigarette"], mechanismTerms:["cyp1a2"] }),
      labelMention: has("tobacco","smoking","nicotine","cigarette"),
      note: has("tobacco","smoking","nicotine","cigarette") ? "FDA labeling returned a smoking/tobacco/nicotine reference." : "The returned FDA label did not contain a direct smoking/tobacco/nicotine interaction statement."
    },
    caffeine: {
      ...classify({ directTerms:["caffeine","coffee"], mechanismTerms:["cyp1a2","stimulant"] }),
      labelMention: has("caffeine","coffee"),
      note: has("caffeine","coffee") ? "FDA labeling returned a caffeine/coffee reference." : "The returned FDA label did not contain a direct caffeine/coffee interaction statement."
    }
  };
}


function analyzeMetabolism(label = {}) {
  const pharmacokinetics = firstArrayValue(label, "pharmacokinetics") || "";
  const pharmacology = firstArrayValue(label, "clinical_pharmacology") || "";
  const interactions = firstArrayValue(label, "drug_interactions") || "";
  const combined = `${pharmacokinetics} ${pharmacology} ${interactions}`.replace(/\s+/g, " ").trim();
  const lower = combined.toLowerCase();
  const enzymeDefs = [
    ["CYP3A4", ["cyp3a4"]], ["CYP2D6", ["cyp2d6"]], ["CYP2C19", ["cyp2c19"]],
    ["CYP2C9", ["cyp2c9"]], ["CYP1A2", ["cyp1a2"]], ["UGT", ["ugt1a", "ugt2b", "glucuronid"]]
  ];
  const enzymes = enzymeDefs.filter(([,terms]) => terms.some(t => lower.includes(t))).map(([name]) => name);
  const metaboliteExcerpt = excerptAround(combined, ["metabolite", "metabolized", "metabolism", "active metabolite", "inactive metabolite"], 340);
  const halfLifeExcerpt = excerptAround(combined, ["half-life", "half life", "elimination half"], 300);
  const eliminationExcerpt = excerptAround(combined, ["renal", "urine", "feces", "excretion", "elimination"], 300);
  return {
    metabolismText: pharmacokinetics || pharmacology || null,
    metaboliteExcerpt: metaboliteExcerpt || "No metabolite-specific language was found in the returned FDA label text.",
    enzymes,
    halfLifeExcerpt: halfLifeExcerpt || "No half-life phrase was found in the returned FDA label text.",
    eliminationExcerpt: eliminationExcerpt || "No elimination/excretion phrase was found in the returned FDA label text.",
    note: "Metabolites can be inactive, active, differently active, or occasionally toxic. A label excerpt alone does not establish how much metabolite is present in a particular person."
  };
}

function analyzeBlackoutRisk(label = {}) {
  const text = labelCorpus(label);
  const lower = text.toLowerCase();
  const groups = [
    ["Memory blackout / amnesia", ["amnesia", "anterograde amnesia", "memory impairment", "memory loss"]],
    ["Fainting / syncope", ["syncope", "fainting", "loss of consciousness"]],
    ["Complex sleep behavior", ["sleep-driving", "sleep driving", "complex sleep behavior", "sleepwalking", "somnambulism"]],
    ["Severe sedation / CNS depression", ["sedation", "somnolence", "central nervous system depression", "respiratory depression"]],
    ["Seizure", ["seizure", "convulsion"]],
    ["Low blood pressure / orthostasis", ["hypotension", "orthostatic"]]
  ];
  const signals = groups.filter(([, terms]) => terms.some(t => lower.includes(t))).map(([name, terms]) => ({ name, excerpt: excerptAround(text, terms, 260) }));
  return {
    signals,
    memoryBlackout: signals.some(x => x.name === "Memory blackout / amnesia"),
    lossOfConsciousness: signals.some(x => x.name === "Fainting / syncope"),
    note: "‘Blackout’ is not one medical diagnosis. It may mean amnesia while awake, fainting/loss of consciousness, a seizure, or a complex sleep behavior. This screen only reports label language and does not prove a medication caused an event."
  };
}

function analyzeMedicationProfile(label = {}) {
  const corpus = labelCorpus(label);
  const lower = corpus.toLowerCase();
  const sedatingTerms = ["sedation", "sedative", "somnolence", "drowsiness", "sleepiness", "impaired alertness"];
  const sedatingHits = sedatingTerms.filter(t => lower.includes(t));
  return {
    whatItsFor: firstArrayValue(label, "indications_and_usage"),
    brainBodySystem: firstArrayValue(label, "clinical_pharmacology") || firstArrayValue(label, "mechanism_of_action"),
    commonSideEffects: firstArrayValue(label, "adverse_reactions"),
    seriousWarnings: firstArrayValue(label, "boxed_warning") || firstArrayValue(label, "warnings_and_cautions") || firstArrayValue(label, "warnings"),
    sedating: sedatingHits.length ? "FDA label contains sedation/drowsiness language" : "No sedation keyword found in returned FDA label",
    sedatingEvidence: sedatingHits
  };
}

function analyzeCaseInteractions(label = {}, queriedDrug = "") {
  const corpus = labelCorpus(label);
  const lower = corpus.toLowerCase();
  const query = queriedDrug.toLowerCase();
  return CLANCY_CASE_MEDS
    .filter(m => !query.includes(m.generic) && !query.includes(m.brand.toLowerCase()))
    .map(m => {
      const terms = [m.generic, m.brand.toLowerCase()];
      const mentioned = terms.some(t => lower.includes(t));
      const excerpt = mentioned ? excerptAround(corpus, terms) : null;
      const studiedCue = mentioned && ["study", "studied", "coadminister", "concomitant", "pharmacokinetic"].some(cue => (excerpt || "").toLowerCase().includes(cue));
      return {
        generic: m.generic,
        brand: m.brand,
        labelMention: mentioned,
        whatHappens: excerpt || "No direct mention of this medication pair was found in the returned FDA label text.",
        actuallyStudiedTogether: studiedCue ? "Possible direct study language found — verify the cited FDA label section" : "Not established by this lookup",
        evidence: mentioned ? "FDA label pair mention" : "No direct pair mention found"
      };
    });
}


function extractDoseInfo(label = {}) {
  const dosage = firstArrayValue(label, "dosage_and_administration") || "";
  const strengths = firstArrayValue(label, "dosage_forms_and_strengths") || "";
  const combined = `${dosage} ${strengths}`.replace(/\s+/g, " ").trim();
  const findExcerpt = (terms) => excerptAround(combined, terms, 240);
  return {
    dosageAndAdministration: dosage || null,
    strengths: strengths || null,
    startingDoseLanguage: findExcerpt(["initial dose", "starting dose", "start at", "recommended starting", "initiate"]),
    maximumDoseLanguage: findExcerpt(["maximum dose", "maximum recommended", "max dose", "should not exceed", "not exceed"]),
    unitGuide: [
      { unit: "ng", name: "nanogram", relation: "1,000 ng = 1 mcg" },
      { unit: "mcg", name: "microgram", relation: "1,000 mcg = 1 mg" },
      { unit: "mg", name: "milligram", relation: "1,000 mg = 1 g" },
      { unit: "g", name: "gram", relation: "1 g = 1,000 mg" }
    ],
    note: "A 'low' or 'high' dose is drug- and patient-specific. Indication, age, route, kidney/liver function, formulation, and other medicines can change the appropriate dose."
  };
}

function riskTags(label = {}) {
  const text = labelCorpus(label).toLowerCase();
  const defs = [
    ["Sedation / CNS depression", ["sedation", "somnolence", "drowsiness", "central nervous system depress", "respiratory depression"]],
    ["Serotonergic effects", ["serotonin syndrome", "serotonergic"]],
    ["QT / rhythm effects", ["qt prolong", "torsade", "arrhythmia"]],
    ["Bleeding", ["bleeding", "hemorrhage", "haemorrhage"]],
    ["Seizure", ["seizure", "convulsion"]],
    ["Blood pressure / orthostasis", ["orthostatic", "hypotension", "hypertension"]],
    ["CYP3A4 metabolism", ["cyp3a4"]],
    ["CYP2D6 metabolism", ["cyp2d6"]],
    ["CYP2C19 metabolism", ["cyp2c19"]],
    ["CYP1A2 metabolism", ["cyp1a2"]]
  ];
  return defs.filter(([, terms]) => terms.some(t => text.includes(t))).map(([name]) => name);
}

function pairMention(label = {}, otherNames = []) {
  const sections = {
    contraindications: firstArrayValue(label, "contraindications") || "",
    interactions: firstArrayValue(label, "drug_interactions") || "",
    warnings: firstArrayValue(label, "warnings_and_cautions") || firstArrayValue(label, "warnings") || "",
    pharmacology: firstArrayValue(label, "clinical_pharmacology") || ""
  };
  const names = otherNames.filter(Boolean).map(x => x.toLowerCase());
  const findIn = (text) => names.some(n => text.toLowerCase().includes(n));
  const direct = Object.entries(sections).filter(([, text]) => findIn(text));
  const combined = Object.values(sections).join(" ");
  const excerpt = direct.length ? excerptAround(combined, names, 260) : null;
  const studyCue = excerpt && ["study", "studied", "coadminister", "co-administer", "concomitant", "pharmacokinetic"].some(c => excerpt.toLowerCase().includes(c));
  return { sections, direct, excerpt, studyCue };
}

function analyzePair(labelA, medA, labelB, medB) {
  if (!labelA || !labelB) return null;
  const aNames = [medA.genericName, ...(medA.brandNames || [])];
  const bNames = [medB.genericName, ...(medB.brandNames || [])];
  const aMentionsB = pairMention(labelA, bNames);
  const bMentionsA = pairMention(labelB, aNames);
  const contraindicated = aMentionsB.direct.some(([k]) => k === "contraindications") || bMentionsA.direct.some(([k]) => k === "contraindications");
  const directMention = aMentionsB.direct.length > 0 || bMentionsA.direct.length > 0;
  const shared = riskTags(labelA).filter(x => riskTags(labelB).includes(x));
  let status = "Compatibility not established by this lookup";
  if (contraindicated) status = "FDA contraindication language may apply — do not combine without prescriber/pharmacist review";
  else if (directMention) status = "Direct FDA-label interaction mention found — review the label details";
  else if (shared.length) status = "No direct pair mention found; overlapping risk signals need clinical review";
  return {
    status,
    directMention,
    contraindicated,
    actuallyStudiedTogether: (aMentionsB.studyCue || bMentionsA.studyCue) ? "Possible study/coadministration language found — verify the exact FDA label section" : "No direct study language identified by this lookup",
    sharedRiskSignals: shared,
    evidenceFromA: aMentionsB.excerpt || "No direct mention of the second medication found in this FDA label section search.",
    evidenceFromB: bMentionsA.excerpt || "No direct mention of the first medication found in this FDA label section search.",
    note: "This is an evidence-screening tool, not a personal medication recommendation. A missing label mention does not prove two drugs are safe together."
  };
}

async function fetchLabelForDrug(drug) {
  const search = encodeURIComponent(`openfda.generic_name:\"${drug}\" OR openfda.brand_name:\"${drug}\"`);
  const labels = await fetchJson(`${FDA}/drug/label.json?search=${search}&limit=5`);
  const label = labels?.results?.[0] || null;
  const openfda = label?.openfda || {};
  return {
    label,
    medication: {
      genericName: firstArrayValue(openfda, "generic_name") || drug,
      brandNames: openfda.brand_name || [],
      manufacturer: firstArrayValue(openfda, "manufacturer_name"),
      route: openfda.route || [],
      productType: firstArrayValue(openfda, "product_type"),
      effectiveTime: label?.effective_time || null
    }
  };
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const drug = cleanDrug(searchParams.get("drug") || "");
  const withDrug = cleanDrug(searchParams.get("with") || "");
  if (!drug) {
    return NextResponse.json({ ok: false, error: "Enter a medication name." }, { status: 400 });
  }

  const labelSearch = encodeURIComponent(`openfda.generic_name:\"${drug}\" OR openfda.brand_name:\"${drug}\"`);
  const eventSearch = encodeURIComponent(`patient.drug.openfda.generic_name:\"${drug}\" OR patient.drug.openfda.brand_name:\"${drug}\"`);

  try {
    const [{ label, medication }, reactions, pairOther] = await Promise.all([
      fetchLabelForDrug(drug),
      fetchJson(`${FDA}/drug/event.json?search=${eventSearch}&count=patient.reaction.reactionmeddrapt.exact&limit=12`),
      withDrug ? fetchLabelForDrug(withDrug) : Promise.resolve(null)
    ]);

    const openfda = label?.openfda || {};

    return NextResponse.json({
      ok: true,
      query: drug,
      medication,
      doseInfo: label ? extractDoseInfo(label) : null,
      metabolismInfo: label ? analyzeMetabolism(label) : null,
      blackoutInfo: label ? analyzeBlackoutRisk(label) : null,
      pairCheck: withDrug && pairOther ? {
        otherMedication: pairOther.medication,
        assessment: analyzePair(label, medication, pairOther.label, pairOther.medication)
      } : null,
      medicationProfile: label ? analyzeMedicationProfile(label) : null,
      label: label ? {
        boxedWarning: firstArrayValue(label, "boxed_warning"),
        warnings: firstArrayValue(label, "warnings_and_cautions") || firstArrayValue(label, "warnings"),
        adverseReactions: firstArrayValue(label, "adverse_reactions"),
        indications: firstArrayValue(label, "indications_and_usage"),
        pregnancy: firstArrayValue(label, "pregnancy") || firstArrayValue(label, "use_in_specific_populations"),
        drugInteractions: firstArrayValue(label, "drug_interactions"),
        pharmacology: firstArrayValue(label, "clinical_pharmacology") || firstArrayValue(label, "mechanism_of_action"),
        metabolism: firstArrayValue(label, "pharmacokinetics")
      } : null,
      faersTopReactions: Array.isArray(reactions?.results)
        ? reactions.results.map((x) => ({ term: x.term, count: x.count }))
        : [],
      everydaySubstances: label ? analyzeEverydaySubstances(label) : null,
      caseInteractionCheck: label ? analyzeCaseInteractions(label, `${drug} ${firstArrayValue(openfda, "generic_name") || ""}`) : [],
      caseStudy: {
        name: "Lindsay Clancy medication timeline",
        note: "Court reporting says 13 psychiatric medications were prescribed over roughly four months. It is unclear how many were actually taken at the same time; a prescription history is not proof of concurrent use.",
        medications: CLANCY_CASE_MEDS
      },
      evidence: {
        label: label ? "FDA prescribing-label evidence" : "No matching FDA label returned",
        faers: reactions?.results?.length
          ? "FAERS reporting signal only — reports can be incomplete, duplicated, confounded, and do not prove the drug caused the event or show incidence."
          : "No matching FAERS reaction counts returned."
      },
      source: "openFDA Drug Label + FAERS public APIs"
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error.message || "Medication safety lookup failed." }, { status: 500 });
  }
}
